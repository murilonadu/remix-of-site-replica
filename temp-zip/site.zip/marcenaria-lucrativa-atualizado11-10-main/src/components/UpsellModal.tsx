import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
interface UpsellModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept: () => void;
  onDecline: () => void;
}
const UpsellModal = ({
  isOpen,
  onClose,
  onAccept,
  onDecline
}: UpsellModalProps) => {
  return <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[480px] bg-card border-border shadow-2xl">
        <DialogHeader>
          <DialogTitle className="text-xl md:text-2xl font-bold text-center mb-2 text-foreground">
            🎉 Antes de seguir, veja esta oferta única! 🎉
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <p className="text-base text-center text-muted-foreground">Por apenas  <span className="text-calm-green font-bold text-lg">R$ 2,90 a mais</span>, você libera mais esse bônus! 
          </p>

          <div className="space-y-2 bg-muted/30 rounded-lg p-3 border-2 border-orange-500">
            <div className="flex gap-2 items-start">
              <div className="text-xl flex-shrink-0">🔧</div>
              <div>
                <h3 className="font-bold text-sm text-foreground mb-0.5">50 Dicas de Performance</h3>
                <p className="text-xs text-muted-foreground">Trabalhe melhor, evite erros e entregue com mais qualidade.</p>
              </div>
            </div>

            <div className="flex gap-2 items-start">
              
              <div>
                
                
              </div>
            </div>
          </div>

          <div className="text-center space-y-1 bg-calm-mint/30 rounded-lg p-3 border border-calm-green/20">
            <p className="text-sm text-foreground font-medium">É pouco no preço… e enorme na vantagem.</p>
            <p className="text-calm-green font-bold text-base">E agora, no NATAL, está praticamente de graça.</p>
          </div>

          <div className="space-y-2">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-calm-green to-calm-green-vibrant rounded-lg blur-md opacity-50 group-hover:opacity-70 transition-opacity duration-300 animate-pulse"></div>
              <Button onClick={() => {
              window.location.href = "https://www.ggcheckout.com/checkout/v2/wd9P6h8Tff6K2A1F2FFt";
            }} size="lg" className="relative w-full bg-gradient-to-r from-calm-green to-calm-green-vibrant hover:from-calm-green-vibrant hover:to-calm-green text-white font-bold text-base py-5 rounded-lg shadow-lg transition-all duration-300 hover:scale-[1.02] animate-pulse">
                SIM, quero tudo por R$ 19,90
              </Button>
            </div>

            <Button onClick={onDecline} size="lg" variant="outline" className="w-full border-border text-muted-foreground hover:bg-muted py-5 rounded-lg">
              Manter sem esse adicional por R$ 17
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>;
};
export default UpsellModal;