import { useState, useEffect } from "react";
import { X } from "lucide-react";
const TopBanner = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [currentMessage, setCurrentMessage] = useState(0);
  const messages = ["⚠️ RESTAM 7 VAGAS", "⏰ BLACK FRIDAY LIMITADA"];
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessage(prev => (prev + 1) % messages.length);
    }, 2000); // Troca a cada 2 segundos

    return () => clearInterval(interval);
  }, []);
  if (!isVisible) return null;
  return <div className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-orange-500 to-orange-600 text-white py-3 px-4 shadow-lg overflow-hidden">
      <div className="container mx-auto">
        <div className="text-center relative h-6">
          {messages.map((message, index) => {})}
        </div>
      </div>
    </div>;
};
export default TopBanner;