import { Shield, Clock, CheckCircle, Infinity, Zap } from "lucide-react";
import { useState, useEffect } from "react";
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
const GuaranteeSection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const features = [{
    icon: Infinity,
    title: "Acesso Vitalício",
    description: "Para sempre em sua conta"
  }, {
    icon: Shield,
    title: "Garantia de 7 Dias",
    description: "Risco zero para você"
  }, {
    icon: Zap,
    title: "Acesso Imediato",
    description: "Receba na hora após o pagamento"
  }];
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide(prev => (prev + 1) % features.length);
    }, 1500);
    return () => clearInterval(timer);
  }, []);
  return <section className="py-12 md:py-16 bg-gradient-to-br from-expandix-dark via-expandix-dark/95 to-expandix-dark relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-8">
          <button onClick={() => {
          const offersSection = document.getElementById('ofertas');
          if (offersSection) {
            const offset = 80;
            const targetPosition = offersSection.getBoundingClientRect().top + window.pageYOffset - offset;
            window.scrollTo({
              top: targetPosition,
              behavior: 'smooth'
            });
          }
        }} className="inline-block mb-6 px-8 py-3 bg-gradient-to-r from-expandix-yellow to-expandix-green font-bold text-lg rounded-full hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-expandix-yellow/50 cursor-pointer text-slate-50 animate-bounce">RESGATAR  BÔNUS EXCLUSIVOS!</button>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 bg-gradient-to-r from-expandix-yellow to-expandix-green bg-clip-text text-transparent">Acesse os projetos pelo Computador, celular ou você pode imprimir!</h2>
          
        </div>
        
        <Carousel opts={{
        align: "start",
        loop: true
      }} className="w-full max-w-5xl mx-auto">
          <CarouselContent>
            {features.map((feature, index) => {
            const Icon = feature.icon;
            return <CarouselItem key={index} className="md:basis-1/3">
                  <div className={`group relative bg-gradient-to-br from-expandix-dark/60 to-expandix-dark/40 rounded-2xl p-5 md:p-6 border transition-all duration-500 hover:scale-105 animate-fade-in backdrop-blur-md ${currentSlide === index ? 'border-expandix-yellow shadow-2xl shadow-expandix-yellow/20 scale-105' : 'border-expandix-green/30 hover:border-expandix-green/50'}`} style={{
                animationDelay: `${index * 0.2}s`
              }}>
                    <div className="absolute inset-0 bg-gradient-to-br from-expandix-green/10 to-expandix-yellow/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                    
                    <div className="relative z-10 text-center space-y-3">
                      <div className={`mx-auto w-12 h-12 md:w-14 md:h-14 rounded-full flex items-center justify-center transition-all duration-500 ${currentSlide === index ? 'bg-gradient-to-r from-expandix-yellow to-expandix-green scale-110 animate-pulse' : 'bg-gradient-to-r from-expandix-green/30 to-expandix-yellow/30 group-hover:scale-110'}`}>
                        <Icon className={`w-6 h-6 md:w-7 md:h-7 ${currentSlide === index ? 'text-expandix-dark' : 'text-expandix-green'}`} />
                      </div>
                      
                      <div>
                        <h3 className="text-lg md:text-xl font-bold text-white mb-2 group-hover:text-expandix-yellow transition-colors duration-300">
                          {feature.title}
                        </h3>
                        <p className="text-sm md:text-base text-green-400/90">
                          {feature.description}
                        </p>
                      </div>
                    </div>
                  </div>
                </CarouselItem>;
          })}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex" />
          <CarouselNext className="hidden md:flex" />
        </Carousel>
      </div>
    </section>;
};
export default GuaranteeSection;