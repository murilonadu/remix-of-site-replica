const AuthorSection = () => {
  return null;
};
export default AuthorSection;