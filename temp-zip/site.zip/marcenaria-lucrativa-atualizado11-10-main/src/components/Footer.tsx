const Footer = () => {
  return <footer className="py-12 bg-foreground text-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            {/* Brand section */}
            <div className="space-y-4">
              
              
              
            </div>
            
            {/* Quick links */}
            <div className="space-y-4">
              
              <ul className="space-y-2 text-background/80 text-sm">
                
                
                
                
              </ul>
            </div>
            
            {/* Contact info */}
            <div className="space-y-4">
              <h4 className="font-semibold">Suporte</h4>
              <div className="space-y-2 text-background/80 text-sm">
                
                <p>🕐 Seg-Sex: 8h às 18h</p>
                
              </div>
            </div>
          </div>
          
          <div className="border-t border-background/20 mt-8 pt-8 text-center">
            <p className="text-background/80 text-sm">© 2025  Manual da  Marcenaria. Todos os direitos reservados.</p>
            
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;