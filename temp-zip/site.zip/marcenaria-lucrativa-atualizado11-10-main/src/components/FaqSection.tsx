import { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import productMockup from "@/assets/product-mockup.png";
const FaqSection = () => {
  const [openItems, setOpenItems] = useState<number[]>([]);
  const faqs = [{
    question: "Esse pacote serve pra qualquer tipo de marcenaria?",
    answer: "Sim! Os projetos incluem desde móveis residenciais até projetos comerciais e industriais. São mais de 1.000 projetos que abrangem todos os segmentos da marcenaria."
  }, {
    question: "Eu preciso saber usar algum programa específico?",
    answer: "Não! Todos os projetos vêm em formatos universais (PDF, DWG) que podem ser abertos em qualquer programa de design ou até mesmo impressos diretamente. Incluímos também versões simplificadas para quem está começando."
  }, {
    question: "Os projetos são atualizados e modernos?",
    answer: "Absolutamente! Nossa equipe atualiza constantemente a biblioteca com tendências atuais do mercado. Todos os projetos seguem as tendências mais modernas e funcionais do design de móveis."
  }, {
    question: "Posso usar esses projetos para vender para meus clientes?",
    answer: "Sim! Você tem total liberdade para usar os projetos comercialmente, modificá-los e vendê-los para seus clientes. Não há restrições de uso comercial."
  }, {
    question: "Recebo na hora?",
    answer: "Sim! O acesso é 100% digital e imediato. Assim que o pagamento for confirmado, você receberá por email o link para download de todo o material."
  }, {
    question: "E se eu não gostar do projeto?",
    answer: "Oferecemos garantia incondicional de 30 dias. Se por qualquer motivo não ficar satisfeito, devolvemos 100% do seu dinheiro, sem perguntas ou burocracias."
  }];
  const toggleItem = (index: number) => {
    setOpenItems(prev => prev.includes(index) ? prev.filter(i => i !== index) : [...prev, index]);
  };
  return <section className="py-12 md:py-16 bg-gradient-to-b from-muted/50 to-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl md:text-4xl font-bold mb-3 bg-gradient-to-r from-expandix-green to-expandix-yellow bg-clip-text text-transparent">Perguntas Frequentes</h2>
            <p className="text-base md:text-lg text-muted-foreground">Aqui estão as dúvidas mais frequentes</p>
          </div>
          
          <div className="space-y-3">
            {faqs.map((faq, index) => <div key={index} className="bg-card rounded-xl shadow-md border border-expandix-green/10 overflow-hidden hover:shadow-lg hover:border-expandix-green/20 transition-all duration-300">
                <button onClick={() => toggleItem(index)} className="w-full p-4 md:p-5 text-left flex items-center justify-between hover:bg-gradient-to-r hover:from-expandix-green/5 hover:to-expandix-yellow/5 transition-colors">
                  <h3 className="text-base md:text-lg font-semibold text-foreground pr-4">
                    {faq.question}
                  </h3>
                  {openItems.includes(index) ? <ChevronUp className="w-5 h-5 text-expandix-green flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-expandix-green flex-shrink-0" />}
                </button>
                
                {openItems.includes(index) && <div className="px-4 md:px-5 pb-4 md:pb-5">
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>}
              </div>)}
          </div>
          
          {/* Product Mockup */}
          <div className="flex justify-center mt-10">
            
          </div>

          <div className="text-center mt-8">
            <button onClick={() => {
            const offersSection = document.getElementById('ofertas');
            if (offersSection) {
              const offset = 80;
              const targetPosition = offersSection.getBoundingClientRect().top + window.pageYOffset - offset;
              window.scrollTo({
                top: targetPosition,
                behavior: 'smooth'
              });
            }
          }} className="inline-block px-8 py-4 bg-gradient-to-r from-expandix-yellow to-expandix-green text-expandix-dark font-bold text-lg rounded-full hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-expandix-yellow/50 cursor-pointer">
              ACESSAR PROJETOS
            </button>
          </div>
        </div>
      </div>
    </section>;
};
export default FaqSection;