import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from "@/components/ui/carousel";
import Autoplay from "embla-carousel-autoplay";
const BonusSection = () => {
  const bonuses = [{
    icon: "📋",
    title: "Checklist Semanal de Autocuidado",
    description: "Um guia passo a passo para incorporar hábitos saudáveis na sua rotina sem sobrecarga",
    color: "bg-calm-green/10 border-calm-green/20"
  }, {
    icon: "🌱",
    title: "Desafio de 7 Dias para Reduzir a Ansiedade",
    description: "Atividades práticas diárias que vão te ajudar a criar momentum e ver resultados rápidos",
    color: "bg-calm-blue/10 border-calm-blue/20"
  }, {
    icon: "🗺️",
    title: "Mapa Emocional Pessoal",
    description: "Um template interativo para você entender seus padrões emocionais e gatilhos pessoais",
    color: "bg-calm-sage/10 border-calm-sage/20"
  }, {
    icon: "🔗",
    title: "Recursos Complementares",
    description: "Links cuidadosamente selecionados para apps, podcasts, meditações guiadas e materiais extras",
    color: "bg-calm-mint/10 border-calm-mint/20"
  }];
  return <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold font-poppins bg-gradient-title-glow bg-clip-text text-transparent animate-fade-in hover:scale-105 transition-all duration-500 cursor-default">Um pouco dos nossos projetos 👇🏻</h2>
            
          </div>
          
          <div className="grid md:grid-cols-2 gap-4">
            {/* Removed bonus cards - keeping only carousel */}
          </div>
          
          {/* Carrossel de Projetos */}
          <div className="mt-16">
            <div className="relative max-w-4xl mx-auto">
              <Carousel 
                plugins={[
                  Autoplay({
                    delay: 3000,
                  }),
                ]}
                opts={{
                  align: "start",
                  loop: true
                }} 
                className="w-full"
              >
                <CarouselContent className="-ml-2 md:-ml-4">
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/60002a16-1b3a-4bec-9965-98f16c441ea2.png" alt="Detalhamento de Guarda Roupa" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/87a70a73-afca-474f-ac37-e1595f9534da.png" alt="Projeto Sala de Estar" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/ad38d3b3-c898-4c68-b546-576ed9504b1c.png" alt="Detalhamento de Armário" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/88ad70ab-8529-4bcf-9321-de2e98b69d5b.png" alt="Projetos de Móveis" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/1013a447-b6fa-45bd-86dc-99187fc7a21e.png" alt="Cuba Esculpida" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                  <CarouselItem className="pl-2 md:pl-4 md:basis-1/2 lg:basis-1/3">
                    <div className="p-1">
                      <div className="rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]">
                        <img src="/lovable-uploads/08b6ce46-91aa-4c1e-8fa6-8167c5ee8c0a.png" alt="Projeto de Cozinha" className="w-full h-64 object-cover" />
                      </div>
                    </div>
                  </CarouselItem>
                </CarouselContent>
                <CarouselPrevious className="left-4" />
                <CarouselNext className="right-4" />
              </Carousel>
            </div>
          </div>
          
          
        </div>
      </div>
    </section>;
};
export default BonusSection;