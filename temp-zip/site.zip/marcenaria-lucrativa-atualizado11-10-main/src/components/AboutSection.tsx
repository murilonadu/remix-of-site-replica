const AboutSection = () => {
  return <section id="para-quem" className="py-6 md:py-10 bg-gradient-to-b from-background to-muted/20 relative overflow-hidden">
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center space-y-6">
          <div className="space-y-3 animate-fade-in">
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold font-poppins bg-gradient-title-primary bg-clip-text text-transparent">Pra quem é o Pack do Marceneiro Rico:</h2>
          </div>
          
          <div className="grid gap-2.5">
            <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-gradient-to-r from-expandix-green/10 to-expandix-yellow/5 border border-expandix-green/20 hover:scale-[1.02] transition-all duration-300">
              <div className="w-7 h-7 bg-gradient-to-r from-expandix-green to-expandix-yellow rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-expandix-dark text-xs font-bold">🧠</span>
              </div>
              <p className="text-sm text-foreground leading-relaxed font-medium">Pra quem cansou de perder tempo desenhando e quer começar a vender.</p>
            </div>
            <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-gradient-to-r from-expandix-green/10 to-expandix-yellow/5 border border-expandix-green/20 hover:scale-[1.02] transition-all duration-300">
              <div className="w-7 h-7 bg-gradient-to-r from-expandix-green to-expandix-yellow rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-expandix-dark text-xs font-bold">💭</span>
              </div>
              <p className="text-sm text-foreground leading-relaxed font-medium">Pra quem quer dobrar a produção sem precisar trabalhar dobrado.</p>
            </div>
            <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-gradient-to-r from-expandix-green/10 to-expandix-yellow/5 border border-expandix-green/20 hover:scale-[1.02] transition-all duration-300">
              <div className="w-7 h-7 bg-gradient-to-r from-expandix-green to-expandix-yellow rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-expandix-dark text-xs font-bold">⚡</span>
              </div>
              <p className="text-sm text-foreground leading-relaxed font-medium">Pra quem quer impressionar o cliente com projetos modernos e bem acabados.</p>
            </div>
            <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-gradient-to-r from-expandix-green/10 to-expandix-yellow/5 border border-expandix-green/20 hover:scale-[1.02] transition-all duration-300">
              <div className="w-7 h-7 bg-gradient-to-r from-expandix-green to-expandix-yellow rounded-lg flex items-center justify-center flex-shrink-0">
                <span className="text-expandix-dark text-xs font-bold">🌱</span>
              </div>
              <p className="text-sm text-foreground leading-relaxed font-medium">Pra quem quer parar de desperdiçar material e aumentar o lucro.</p>
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default AboutSection;