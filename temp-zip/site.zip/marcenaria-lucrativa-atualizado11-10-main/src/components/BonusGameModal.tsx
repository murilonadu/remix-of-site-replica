import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Gift, Sparkles } from "lucide-react";
interface BonusGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onComplete: (bonuses: string[]) => void;
}
const BonusGameModal = ({
  isOpen,
  onClose,
  onComplete
}: BonusGameModalProps) => {
  const [selectedBoxes, setSelectedBoxes] = useState<number[]>([]);
  const [revealedBonuses, setRevealedBonuses] = useState<string[]>([]);
  const [gameComplete, setGameComplete] = useState(false);
  const bonuses = ["🎯 E-book: Como Precificar Seus Móveis", "📐 300 Templates de Medidas Padrão", "🎥 Curso de Acabamentos Premium", "💼 Kit de Contratos Profissionais", "🔧 Guia de Ferramentas Essenciais", "📊 Planilha de Gestão de Estoque"];
  const handleBoxClick = (boxIndex: number) => {
    if (selectedBoxes.includes(boxIndex) || selectedBoxes.length >= 1) return;
    const newSelected = [...selectedBoxes, boxIndex];
    setSelectedBoxes(newSelected);

    // Always give the same discount offer - 50% off for R$ 19,90
    const discountOffer = "🎁 DESCONTO DE 50% - Apenas R$ 19,90 + 3 Bônus Exclusivos!";
    setRevealedBonuses([discountOffer]);
    if (newSelected.length === 1) {
      setGameComplete(true);
    }
  };
  const handleContinue = () => {
    onComplete(revealedBonuses);
    onClose();
    // Reset state for next time
    setSelectedBoxes([]);
    setRevealedBonuses([]);
    setGameComplete(false);
  };
  return <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl bg-gradient-to-br from-expandix-dark via-expandix-dark/95 to-expandix-dark border border-expandix-green/30">
        <div className="text-center space-y-6 p-6">
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-expandix-green/20 to-expandix-yellow/20 rounded-full blur-2xl"></div>
            <div className="relative w-20 h-20 bg-gradient-to-r from-expandix-green/30 to-expandix-yellow/30 rounded-full flex items-center justify-center mx-auto border border-expandix-green/50 animate-pulse">
              <Gift className="w-10 h-10 text-expandix-yellow" />
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-3xl md:text-4xl font-bold text-white font-poppins">
              Antes de Continuar, veja se você tem um desconto.
            </h2>
            
          </div>

          {!gameComplete ? <div className="grid grid-cols-3 gap-6 max-w-xl mx-auto px-4">
              {Array.from({
            length: 3
          }, (_, i) => <div key={i} onClick={() => handleBoxClick(i)} className={`
                    relative h-20 sm:h-24 md:h-32 cursor-pointer transition-all duration-300 rounded-xl border-2
                    ${selectedBoxes.includes(i) ? 'bg-gradient-to-br from-expandix-green/50 to-expandix-yellow/50 border-expandix-yellow scale-105 shadow-lg shadow-expandix-yellow/30' : 'bg-gradient-to-br from-expandix-dark/80 to-expandix-dark/60 border-expandix-green/30 hover:border-expandix-yellow/50 hover:scale-105'}
                  `}>
                  <div className="absolute inset-0 flex items-center justify-center">
                    {selectedBoxes.includes(i) ? <div className="text-center animate-bounce">
                        <Sparkles className="w-6 h-6 text-expandix-yellow mx-auto mb-1" />
                        <span className="text-xs font-bold text-white">R$ 97,00</span>
                      </div> : <div className="text-center">
                        <Gift className="w-6 h-6 text-expandix-green/70 mx-auto mb-1" />
                        <span className="text-xs text-expandix-green/70">?</span>
                      </div>}
                  </div>
                </div>)}
            </div> : <div className="space-y-6">
              <h3 className="text-2xl font-bold text-expandix-yellow">R$ 47,00</h3>
              <div className="grid gap-4 max-w-2xl mx-auto">
                {revealedBonuses.map((bonus, index) => <div key={index} className="bg-gradient-to-r from-expandix-green/20 to-expandix-yellow/20 rounded-xl p-4 border border-expandix-green/30 animate-fade-in" style={{
              animationDelay: `${index * 0.2}s`
            }}>
                    <p className="text-white font-semibold">{bonus}</p>
                  </div>)}
              </div>
              
              <Button onClick={handleContinue} size="lg" className="bg-gradient-to-r from-expandix-green to-expandix-yellow hover:from-expandix-yellow hover:to-expandix-green text-expandix-dark font-bold text-lg py-4 px-8 rounded-xl shadow-xl transition-all duration-300 hover:scale-105 animate-pulse">
                CONTINUAR PARA O PAGAMENTO
              </Button>
            </div>}

          <div className="text-sm text-expandix-green/70">
            {selectedBoxes.length < 1 ? "Escolha 1 caixa para revelar seu desconto" : gameComplete ? "Seu desconto especial foi ativado!" : "Clique para revelar seu desconto..."}
          </div>
        </div>
      </DialogContent>
    </Dialog>;
};
export default BonusGameModal;