import { useState, useEffect } from "react";
const InstantAccessSection = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = [{
    icon: "🛡️",
    title: "Garantia de 30 Dias",
    description: "Risco zero para você",
    color: "from-blue-400 to-blue-600"
  }, {
    icon: "♾️",
    title: "Acesso Vitalício",
    description: "Para sempre em sua conta",
    color: "from-purple-400 to-purple-600"
  }, {
    icon: "⚡",
    title: "Acesso Imediato",
    description: "Receba na hora após o pagamento",
    color: "from-green-400 to-green-600"
  }];
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStep(prev => (prev + 1) % steps.length);
    }, 3000);
    return () => clearInterval(timer);
  }, [steps.length]);
  return null;
};
export default InstantAccessSection;