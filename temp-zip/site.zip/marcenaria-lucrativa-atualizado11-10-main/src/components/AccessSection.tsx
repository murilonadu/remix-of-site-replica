import { Play, CheckCircle, Shield } from "lucide-react";
const AccessSection = () => {
  return <div></div>;
};
export default AccessSection;