import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ContentSection from "@/components/ContentSection";
import TargetAudienceSection from "@/components/TargetAudienceSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import BonusSection from "@/components/BonusSection";
import AuthorSection from "@/components/AuthorSection";
import GuaranteeSection from "@/components/GuaranteeSection";
import FinalCtaSection from "@/components/FinalCtaSection";
import Footer from "@/components/Footer";
import TopBanner from "@/components/TopBanner";
import PurchaseNotifications from "@/components/PurchaseNotifications";
import FaqSection from "@/components/FaqSection";
import AccessSection from "@/components/AccessSection";
import InstantAccessSection from "@/components/InstantAccessSection";

const Index = () => {
  return (
    <div className="min-h-screen font-inter">
      <TopBanner />
      <PurchaseNotifications />
      <div className="pt-12">
        <HeroSection />
        <ContentSection />
        <TargetAudienceSection />
        <TestimonialsSection />
        <BonusSection />
        <AboutSection />
        <AuthorSection />
        <GuaranteeSection />
        <FinalCtaSection />
        <AccessSection />
        <InstantAccessSection />
        <FaqSection />
        <Footer />
      </div>
    </div>
  );
};

export default Index;
